<!--**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to https://devdocs.prestashop.com/ for more information.
 *
 * @author    PrestaShop SA and Contributors <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 *-->
<template>
  <div class="row product-actions">
    <div
      class="col-md-8 qty d-flex align-items-center"
      :class="{'active' : isFocused}"
    >
      <PSCheckbox
        id="bulk-action"
        ref="bulk-action"
        class="mt-3"
        :is-indeterminate="isIndeterminate()"
        @checked="bulkChecked"
      />
      <div class="ml-2">
        <small>{{ trans('title_bulk') }}</small>
        <PSNumber
          class="bulk-qty"
          :danger="danger"
          :value="bulkEditQty"
          :buttons="isFocused"
          @focus="focusIn"
          @blur="focusOut($event)"
          @change="onChange"
          @keyup="onKeyUp"
        />
      </div>
    </div>
    <div class="col-md-4">
      <PSButton
        type="button"
        class="update-qty float-sm-right my-4 mr-2"
        :class="{'btn-primary': disabled }"
        :disabled="disabled"
        :primary="true"
        @click="sendQty"
      >
        <i class="material-icons">edit</i>
        {{ trans('button_movement_type') }}
      </PSButton>
    </div>
  </div>
</template>

<script lang="ts">
  import PSNumber from '@app/widgets/ps-number.vue';
  import PSCheckbox from '@app/widgets/ps-checkbox.vue';
  import PSButton from '@app/widgets/ps-button.vue';
  import {EventEmitter} from '@components/event-emitter';
  import {defineComponent} from 'vue';
  import TranslationMixin from '@app/pages/stock/mixins/translate';

  export default defineComponent({
    computed: {
      disabled(): boolean {
        return !this.$store.state.hasQty;
      },
      bulkEditQty(): number {
        return this.$store.state.bulkEditQty;
      },
      selectedProductsLng(): any {
        return this.$store.getters.selectedProductsLng;
      },
    },
    mixins: [TranslationMixin],
    watch: {
      selectedProductsLng(value: number): void {
        if (value === 0 && this.$refs['bulk-action']) {
          (<HTMLInputElement> this.$refs['bulk-action']).checked = false;
          this.isFocused = false;
        }
        if (value === 1 && this.$refs['bulk-action']) {
          this.isFocused = true;
        }
      },
    },
    methods: {
      isIndeterminate(): boolean {
        const {selectedProductsLng} = this;
        const productsLng = this.$store.state.products.length;
        const isIndeterminate = (selectedProductsLng > 0 && selectedProductsLng < productsLng);

        if (isIndeterminate) {
          (<HTMLInputElement> this.$refs['bulk-action']).checked = true;
        }
        return isIndeterminate;
      },
      focusIn(): void {
        this.danger = !this.selectedProductsLng;
        this.isFocused = !this.danger;
        if (this.danger) {
          EventEmitter.emit('displayBulkAlert', 'error');
        }
      },
      focusOut(event: Event): void {
        this.isFocused = $(<HTMLInputElement>event.target).hasClass('ps-number');
        this.danger = false;
      },
      bulkChecked(checkbox: HTMLInputElement): void {
        if (!checkbox.checked) {
          this.$store.dispatch('updateBulkEditQty', null);
        }
        if (!this.isIndeterminate()) {
          EventEmitter.emit('toggleProductsCheck', checkbox.checked);
        }
      },
      sendQty(): void {
        this.$store.state.hasQty = false;
        this.$store.dispatch('updateQtyByProductsId');
      },
      onChange(event: Event): void {
        this.$store.dispatch('updateBulkEditQty', (<HTMLInputElement>event.target).value);
      },
      onKeyUp(event: Event): void {
        this.isFocused = true;
        const inputValue = (<HTMLInputElement>event.target).value;
        this.$store.dispatch(
          'updateBulkEditQty',
          inputValue.length ? parseInt(inputValue, 10) : inputValue,
        );
      },
    },
    data() {
      return {
        isFocused: false,
        danger: false,
      };
    },
    components: {
      PSNumber,
      PSCheckbox,
      PSButton,
    },
  });
</script>
